---
priority: 0.6
title: Project X
excerpt: An example of a and b
categories: works
background-image: works-sample.png
tags:
  - This
  - That
  - The other
---

#### Results

- 18% increase in M, measured by N
- ...

#### Summary

Project X involved ....
