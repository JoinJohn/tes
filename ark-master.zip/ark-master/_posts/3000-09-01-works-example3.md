---
priority: 0.6
title: Project Z
excerpt: An example of d and e
categories: works
background-image: works-sample.png
tags:
  - This
  - That
  - The other
---

#### Results

- 19% increase in M, measured by N
- ...

#### Summary

Project Z involved ....
