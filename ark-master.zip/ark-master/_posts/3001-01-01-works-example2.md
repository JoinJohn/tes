---
priority: 0.7
title: Project Y
excerpt: A better example of a and b, with c
categories: works
background-image: works-sample.png
tags:
  - This
  - That
  - The other
---

#### Results

- 24% increase in M, measured by N
- ...

#### Summary

Project Y involved ....
