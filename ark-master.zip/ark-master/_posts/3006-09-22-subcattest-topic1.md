---
title: My Topic Group
excerpt: first topic in my neat grouping
permalink: /topics/my topic group/
categories:
  - topics
  - my topic group
date: 3006-09-22 00:00
---

Here we go.
