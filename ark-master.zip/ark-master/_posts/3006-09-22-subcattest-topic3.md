---
title: Last topic in group
excerpt: last topic
categories:
  - topics
  - my topic group
date: 3006-09-22 00:02
---

This about sums it all up.
